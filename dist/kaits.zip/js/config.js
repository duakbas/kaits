// EDIT THIS FILE. These two values point the app at your daemon.
//
// While developing in a desktop browser, run the daemon locally and use:
//   ws://localhost:8080/ws
// On the real phone over the internet, you MUST use wss:// (TLS) or KaiOS
// may refuse the connection and your token travels in the clear:
//   wss://your-domain/ws
//
// TOKEN must match WAD_TOKEN you set when starting the daemon.

window.CONFIG = {
  DAEMON_WS: "ws://localhost:8080/ws",
  TOKEN: "changeme",

  // Reconnect backoff (ms). KaiOS backgrounds the app aggressively, so the
  // socket WILL drop; this controls how fast we retry.
  RECONNECT_MIN: 1000,
  RECONNECT_MAX: 15000,

  // Show the on-screen key log from startup. You rarely need this: pressing *
  // three times toggles it on the phone at any point, which is easier than
  // rebuilding. Errors appear on that strip regardless of this setting.
  DEBUG_KEYS: false,

  // Buzz when a message arrives in the chat you already have open. Off by
  // default: you're looking straight at it, so the buzz tells you nothing the
  // screen didn't. Flip it if you'd rather feel every message.
  VIBRATE_IN_OPEN_CHAT: false,

  // How the app alerts you. "auto" follows the phone's own notification
  // profile — silent mode silences the beep, vibration-off stops the buzz —
  // and falls back to the values below when the phone won't tell us (always
  // the case in a desktop browser, and possibly on the phone, since reading
  // settings is permission-gated).
  //
  // "always" and "never" ignore the phone and do what they say.
  //
  // Fallbacks when nothing is known: vibrate yes, beep no. A missed buzz beats
  // a browser tab beeping at you in a meeting.
  NOTIFY_VIBRATE: "auto",
  NOTIFY_SOUND: "auto",

  // Which audio channel the keepalive plays on. This is the one knob that
  // decides whether the trick works AND whether it is antisocial:
  //
  //   "normal"  — non-exclusive. Should not stop your music or any other
  //               sound. May or may not be enough for the platform to count
  //               the app as busy; if kills continue with the keepalive on and
  //               playing, that is what this being too polite looks like.
  //   "content" — the media channel. Certain to count, and certain to stop
  //               whatever else is using it every time you leave the app.
  //
  // Start on "normal". Only reach for "content" if the Settings screen shows
  // the keepalive playing and the kill rate has not moved.
  KEEPALIVE_CHANNEL: "normal",

  // Playback volume for the keepalive loop, on top of a file that is already
  // 1% of full scale. 0.01 puts -80 dBFS at the output — about 20 dB SPL on
  // headphones at maximum volume, against a hearing threshold of roughly
  // 78 dB SPL at the loop's 20 Hz. Nearly 60 dB of margin, and headphones are
  // the demanding case: a phone speaker cannot reproduce 20 Hz at all.
  //
  // Do NOT set this to 0. Zero volume, a muted element and digital silence are
  // the three ways to be counted INAUDIBLE, and an inaudible app is precisely
  // the one the priority manager ignores — it would make the keepalive silent
  // and useless rather than silent and working.
  KEEPALIVE_VOLUME: 0.01
};

window.KAITS_VERSION = "1.9.0";
window.KAITS_BUILT = 1789695892000;
